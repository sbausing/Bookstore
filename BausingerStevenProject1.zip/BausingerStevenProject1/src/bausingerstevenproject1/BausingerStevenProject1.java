/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bausingerstevenproject1;
import java.util.Scanner;

/**
 *
 * @author steve
 */
public class BausingerStevenProject1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Bookstore store = new Bookstore();
        Inventory inv = new Inventory();
        Scanner sc = new Scanner(System.in);
        
        System.out.println("Please select from the following menu of options, by typing a number:");
        System.out.println("\t 1. Purchase items");
        System.out.println("\t 2. Check membership status");
        System.out.println("\t 3. Change payment method");
        System.out.println("\t 4. Quit");
        
        int num = sc.nextInt();
        switch (num) {
        case 1:
            System.out.println("Are you an existing premium member? (Y/N)");
            char letter = sc.next().charAt(0);
            int id = 0;
            if(letter == 'Y' || letter == 'y') {
            System.out.println("What is your ID number?");
            id = sc.nextInt();
             }
            Customer newCustomer = store.getCustomer(id);
            if(store.getCustomer(id).isFeeOwed()) {
            System.out.println("You owe your monthly fee. It will be automatically processed at checkout");
            }
            System.out.println("How many books do you want?");
            int books = sc.nextInt();
            newCustomer.setBooks(books);
            System.out.println("How many DVDs do you want?");
            int dvds = sc.nextInt();
            newCustomer.setDVDs(dvds);
            System.out.println("How many CDs do you want?");
            int cds = sc.nextInt();
            newCustomer.setCDs(cds);
            System.out.println("You have ordered: " + newCustomer.getBooks() + " books, " + newCustomer.getDVDs() + " DVDs, and " + newCustomer.getCDs() + " CDs.");
            if(newCustomer.isPremium()) {
                if(newCustomer.isFeeOwed()) {
                    System.out.println("Your monthly fee has been added to your total");
                }
            }
            System.out.println("Your total is $" + newCustomer.checkout());
            if(newCustomer.isPremium()) {
                System.out.println("Your total amount spent at the bookstore is $" + newCustomer.getAmountSpent());
            }
            inv.removeFromInventory(books, dvds, cds);
            System.out.println("The new inventory is:");
            System.out.println("Books : " + inv.getAmtBooks());
            System.out.println("DVDs : " + inv.getAmtDVDs());
            System.out.println("CDs : " + inv.getAmtCDs());
            break;
        case 2:
            System.out.println("What was your premium id?");
            int previousID = sc.nextInt();
            if(store.isCustomerPremium(previousID)) {
                System.out.println("You are still a premium member");
            }
            else {
                System.out.println("You are not a premium member");
            }
            break;
        case 3:
            System.out.println("Would you like your payment method to be?");
            sc.nextLine();
            String method = sc.nextLine();
            id = 0;
            System.out.println("What is your ID number?");
            id = sc.nextInt();
            Customer customer = store.getCustomer(id);
            customer.setPaymentType(method);
            System.out.println("Your payment type is now " + customer.getPaymentType());
            break;
        case 4:
            break;
        }
    }
}
