/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bausingerstevenproject1;

/**
 *
 * @author steve
 */
public class Inventory {
    int books = 100;
    int dvds = 100;
    int cds = 100;
    
    public Inventory() {
    }
    
    public int getAmtBooks() {
        return books;
    }
    
    public void setAmtBooks(int b) {
        books -= b;
    }
    
    public int getAmtDVDs() {
        return dvds;
    }
    
    public void setAmtDVDs(int d) {
        books -= d;
    }
    
    public int getAmtCDs() {
        return cds;
    }
    
    public void setAmtCDs(int c) {
        books -= c;
    }
    
    public void removeFromInventory(int b, int d, int c) {
        books -= b;
        dvds -= d;
        cds -= c;
    }
}
