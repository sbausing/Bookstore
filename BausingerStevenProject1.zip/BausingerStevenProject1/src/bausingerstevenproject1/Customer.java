/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bausingerstevenproject1;

/**
 *
 * @author steve
 */
public class Customer {
    private int numBooks = 0;
    private int numCDs = 0;
    private int numDVDs = 0;
    private int amountOwed = 0;
    private double amountSpent = 0.0;
    private boolean premium = false;
    private boolean feeOwed = false;
    private String paymentType = "";
    private int custID = 0;
    private double fee = 29.99;
    
    public Customer() {
    }
    
    public Customer(int id) {
        custID = id;
    }
    
    public Customer(boolean p, boolean fOwed, String pay, int id, double spent) {
        premium = p;
        feeOwed = fOwed;
        paymentType = pay;
        custID = id;
        amountSpent = spent;
    }
    
    public int getBooks() {
        return numBooks;
    }
    
    public void setBooks(int books) {
        numBooks = books;
    }
    
    public int getCDs() {
        return numCDs;
    }
    
    public void setCDs(int cds) {
        numCDs = cds;
    }
    
    public int getDVDs() {
        return numDVDs;
    }
    
    public void setDVDs(int dvds) {
        numDVDs = dvds;
    }
    
    public int getAmountOwed() {
        return amountOwed;
    }
    
    public void setAmountOwed(int owed) {
        amountOwed = owed;
    }
    
    public boolean isPremium() {
        return premium;
    }
    
    public double getFee() {
        return fee;
    }
    
    public void setFee(double f) {
        fee = f;
    }
    
    public boolean isFeeOwed() {
        return feeOwed;
    }
    
    public String getPaymentType() {
        return paymentType;
    }
    
    public void setPaymentType(String p) {
        paymentType = p;
    }
    
    public int getCustID() {
        return custID;
    }
    
    public void setCustID(int id) {
        custID = id;
    }
    
    public double getAmountSpent() {
        return amountSpent;
    }
    
    public void setAmountSpent(double spent) {
        amountSpent = spent;
    }
    
    public double checkout() {
        double totBooks = (double)numBooks * 39.99;
        System.out.println(totBooks);
        double totDVDs = (double)numDVDs * 34.99;
        System.out.println(totDVDs);
        double totCDs = (double)numCDs * 24.99;
        System.out.println(totCDs);
        double total = (Math.round((totBooks + totDVDs + totCDs)*100))/100.0;
        if(feeOwed) {
            total = (Math.round((total+fee)*100))/100.0;
        }
        if(premium) {
            amountSpent += total;
        }
        return total;
    }
}
