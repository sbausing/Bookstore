/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package bausingerstevenproject1;

import java.util.ArrayList;

/**
 *
 * @author steve
 */
public class Bookstore extends Customer {
   public ArrayList<Customer> customerList = new ArrayList<>();
   
   public Bookstore() {
       customerList.add(new Customer(0));
       customerList.add(new Customer(true, false, "Card", 1, 100.0));
       customerList.add(new Customer(true, false, "Cash", 2, 200.0));
       customerList.add(new Customer(true, true, "Card", 3, 150.0));
       customerList.add(new Customer(true, true, "PayPal", 4, 75.0));
   }
   
   public int findCustomerBin(int custID) {
       int left = 0;
      int right = customerList.size() - 1;
      while (left <= right) {
         int middle = (left + right) / 2;
         if (custID < customerList.get(middle).getCustID()) {
            right = middle - 1;
         }
         else if (custID > customerList.get(middle).getCustID()) {
             left = middle + 1;
         }
         else {
             return middle;
         }
      }
      return -1;
   }
   
   public Customer getCustomer(int id) {
       for(int i = 0; i < customerList.size(); i++) {
           if(customerList.get(i).getCustID() == id) {
               return customerList.get(i);
           }
       }
       Customer c1 = new Customer();
       return c1;
   }
   
   public boolean isCustomerPremium(int custID) {
       insertionSort();
        for(int i=0;i<customerList.size();i++) {
            if(custID == (customerList.get(i)).getCustID()) {        
                return true;
            }
        }
        return false;
    }
   
   public void insertionSort() {
        for (int j = 1; j < customerList.size(); j++)
      {
         Customer temp = customerList.get(j);
         int possibleIndex = j;
         while (possibleIndex > 0 && temp.getCustID()< customerList.get(possibleIndex - 1).getCustID())
         {
            customerList.set(possibleIndex, customerList.get(possibleIndex - 1));
            possibleIndex--;
         }
         customerList.set(possibleIndex, temp);
      }
    }
}